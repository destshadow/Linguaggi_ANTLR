import java.util.Scanner;

public class Brainfuck extends BrainfuckBaseVisitor<Integer> {

    byte[] byteArray = new byte[30000]; //già inizializzato a 0
    int pointer = 0;

    @Override
    public Integer visitMain(BrainfuckParser.MainContext ctx) {
        return visit(ctx.com());
    }

    @Override
    public Integer visitLt(BrainfuckParser.LtContext ctx) {
        pointer--;
        return visit(ctx.com());
    }

    @Override
    public Integer visitGt(BrainfuckParser.GtContext ctx) {
        pointer++;
        return visit(ctx.com());
    }

    @Override
    public Integer visitPlus(BrainfuckParser.PlusContext ctx) {
        byteArray[pointer]++;
        return visit(ctx.com());
    }

    @Override
    public Integer visitMinus(BrainfuckParser.MinusContext ctx) {
        byteArray[pointer]--;
        return visit(ctx.com());
    }

    @Override
    public Integer visitDot(BrainfuckParser.DotContext ctx) {
        System.out.print(byteArray[pointer]);
        return visit(ctx.com());
    }


    @Override
    public Integer visitComma(BrainfuckParser.CommaContext ctx) {
        Scanner scanner = new Scanner(System.in);
        byte inputByte = scanner.nextByte();
        byteArray[pointer] = inputByte;
        return visit(ctx.com());
    }


    @Override
    public Integer visitLoop(BrainfuckParser.LoopContext ctx) {
        if(ctx.LBRAK().getText().equals("[")){
            if(byteArray[pointer] == 0){
                while(byteArray[pointer] != 0){

                }
            }
        }

        return visitChildren(ctx);
    }

    @Override
    public Integer visitNil(BrainfuckParser.NilContext ctx) {
        return visitChildren(ctx);
    }
}
